# 단어 시퀀스 벡터 크기
MAX_SEQ_LEN = 15


def GlobalParams():
    global MAX_SEQ_LEN
